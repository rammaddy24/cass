package com.rnfs;

public class DownloadResult {
  public int statusCode;
  public long bytesWritten;
  public Exception exception;
}
