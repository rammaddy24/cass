import React, { Component, PureComponent } from 'react'
import {
    StyleSheet, Text, Keyboard, AsyncStorage, FlatList,
    View, TouchableOpacity, Image, SafeAreaView, ImageBackground, BackHandler, Alert, Platform, Modal, TextInput, ScrollView, TouchableWithoutFeedback
} from 'react-native'
import { color, width, fontSize, fontFamily, height, LG_BG_THEME, Notify_THEME } from '../../../Constants/fontsAndColors'
import { Container, Content, connect, Picker, Header, LinearGradient, Snackbar, CalendarPicker, Moment } from '../../../../Asset/Libraries/NpmList';
import { Mystatusbar, isIOS } from '../../../../Asset/Libraries/index'
import BottomNavigation, { ShiftingTab } from 'react-native-material-bottom-navigation'
import Sample_json from '../Extra_Modules/Screenlist.json'

import { AS_HeaderDesign } from '../../CommonView_Modules/AS_HeaderDesign'
import { AS_TextView } from '../../CommonView_Modules/AS_TextView'
import { AS_Textbutton } from '../../CommonView_Modules/AS_Textbutton'

import { AS_SidebardDesign } from '../../CommonView_Modules/AS_SidebardDesign'
import { CardList_Design } from '../../CommonView_Modules/CardList_Design'
import { MsgCardlist_Design } from '../../CommonView_Modules/MsgCardlist_Design'
import { Card_Joblist } from '../../CommonView_Modules/Card_Joblist'
import { CM_ButtonDesign } from '../../CommonView_Modules/CM_ButtonDesign'
import { ViewAll_Design } from '../../CommonView_Modules/ViewAll_Design'
import { Home_Msgcard } from '../../CommonView_Modules/Home_Msgcard'
import { Home_Headertext } from '../../CommonView_Modules/Home_Headertext'
import { Home_Timesheetscard } from '../../CommonView_Modules/Home_Timesheetscard'
import { Home_Usertext } from '../../CommonView_Modules/Home_Usertext'
import { Modal_Text } from '../../CommonView_Modules/Modal_Text'

import { Basic_Auth, User_Info, Message_List, Notification_List, Cass_APIKEY } from '././../../../Config/Server'
import { NotifyInfo_Action } from '../../../../Redux/Actions/NotifyInfo_Action'
import { UserInfo_Action } from '../../../../Redux/Actions/UserInfo_Action'

import { Spinner } from '../../../Config/Spinner';
import GestureRecognizer, { swipeDirections } from '../../../Constants/GestureRecognizer'

class Dashboard extends Component {

    constructor(props) {
        super(props);
        this.state = {
            ActiveTab: "Home",
            Notifications_Tab: "Messages",

            Calendar_Date: "",
            CD_Month: "",
            CD_Year: "",
            CD_Date: "",

            Timesheet_Date: "",
            TD_Month: "",
            TD_Year: "",
            TD_Date: "",

            Msg_ResponseArray: [],
            Notify_ResponseArray: [],
            User_ResponseArray: "",
            Info_Modal: false,

            CassUserID: "",
            CassRoleID: "",
            Dashboard_Fetching: false,
            Message_ListCount: 0,
            Message_ListIndex: 0

        };

    }

    componentDidMount() {

        AsyncStorage.getItem("Cass_UserID", (error, Token_Result) => {
            if (Token_Result != "0" || Token_Result != null) {
                AsyncStorage.getItem("Cass_RoleID", (error, Token_RoleID) => {
                    if (Token_RoleID != "0" || Token_RoleID != null) {
                        this.setState({ CassUserID: Token_Result, CassRoleID: Token_RoleID, Dashboard_Fetching: true }, () => this._fetchdata(Token_Result, Token_RoleID));
                    }
                })
            }
        })


        var Current_Date = new Date(new Date().getTime())
        this.setState({
            Calendar_Date: Moment(Current_Date).format('YYYY-MM-DD'),
            CD_Year: Moment(Current_Date).format('YYYY'),
            CD_Month: Moment(Current_Date).format('MMMM'),
            CD_Date: Moment(Current_Date).format('DD'),
            Timesheet_Date: Moment(Current_Date).format('YYYY-MM-DD'),
            TD_Year: Moment(Current_Date).format('YYYY'),
            TD_Month: Moment(Current_Date).format('MMMM'),
            TD_Date: Moment(Current_Date).format('DD')
        })


    }

    async _fetchdata(Token_Result, Token_RoleID) {
        const UserInfo_Response = await this._fetch_UserInfo(Token_Result, Token_RoleID);
        const MsgInfo_Response = await this._fetch_MsgInfo(Token_Result, Token_RoleID);
        const NotifyInfo_Response = await this._fetch_NotifyInfo(Token_Result, Token_RoleID);
        try {
            this.setState({
                Msg_ResponseArray: MsgInfo_Response.Msg_Info,
                Notify_ResponseArray: NotifyInfo_Response.Notify_Info,
                User_ResponseArray: UserInfo_Response.User_Info,
                Message_ListCount: MsgInfo_Response.Msg_Info.length,
                Dashboard_Fetching: false
            })


            this.props.NotifyInfo_Action(NotifyInfo_Response.Notify_Info)
            this.props.UserInfo_Action(UserInfo_Response.User_Info)

        } catch (err) {
            this.setState({ Dashboard_Fetching: false });
        }
    }

    _fetch_UserInfo(Token_Result, Token_RoleID) {
        return new Promise((resolve, reject) => {
            let UserInfo_URL = User_Info + Token_Result + "&user_role=" + Token_RoleID + Cass_APIKEY;
            fetch(UserInfo_URL, {
                method: 'GET',
                headers: Basic_Auth
            })
                .then((response) => response.json())
                .then((Jsonresponse) => {
                    let User_Info = ""
                    if (Jsonresponse.status == true) {
                        User_Info = Jsonresponse.data
                        resolve({ User_Info });
                    } else {
                        reject(User_Info)
                    }
                })
                .catch((error) => {
                    this.setState({ Dashboard_Fetching: false });
                    Snackbar.show({
                        title: "Internal Server Error..!",
                        duration: Snackbar.LENGTH_SHORT,
                    });
                });
        });
    }

    _fetch_MsgInfo(Token_Result, Token_RoleID) {
        return new Promise((resolve, reject) => {
            let MsgInfo_URL = Message_List + Token_Result + "&user_role=" + Token_RoleID + Cass_APIKEY;
            fetch(MsgInfo_URL, {
                method: 'GET',
                headers: Basic_Auth
            })
                .then((response) => response.json())
                .then((Jsonresponse) => {
                    let Msg_Info = ""
                    if (Jsonresponse.status != false) {
                        Msg_Info = Jsonresponse
                        resolve({ Msg_Info });
                    } else {
                        reject(Msg_Info)
                    }
                })
                .catch((error) => {
                    this.setState({ Dashboard_Fetching: false });

                    Snackbar.show({
                        title: "Internal Server Error..!",
                        duration: Snackbar.LENGTH_SHORT,
                    });
                });
        });
    }

    _fetch_NotifyInfo(Token_Result, Token_RoleID) {
        return new Promise((resolve, reject) => {
            let NotifyInfo_URL = Notification_List + Token_Result + "&user_role=" + Token_RoleID + Cass_APIKEY;
            fetch(NotifyInfo_URL, {
                method: 'GET',
                headers: Basic_Auth
            })
                .then((response) => response.json())
                .then((Jsonresponse) => {
                    let Notify_Info = ""
                    if (Jsonresponse.status != false) {
                        Notify_Info = Jsonresponse
                        resolve({ Notify_Info });
                    } else {
                        reject(Notify_Info)
                    }
                })
                .catch((error) => {
                    this.setState({ Dashboard_Fetching: false });
                    Snackbar.show({
                        title: "Internal Server Error..!",
                        duration: Snackbar.LENGTH_SHORT,
                    });
                });
        });
    }


    //......Bottom Navigation Tab Bar......//

    tabs = [
        {
            key: 'Home',
            icon: 'Home',
            label: 'Home',
            barColor: LG_BG_THEME.WHITE_THEME,
            pressColor: LG_BG_THEME.WHITE_THEME,
        },
        {
            key: 'Calendar',
            icon: 'Calendar',
            label: 'Calendar',
            barColor: LG_BG_THEME.WHITE_THEME,
            pressColor: LG_BG_THEME.WHITE_THEME,
        },
        {
            key: 'Timesheet',
            icon: 'Timesheet',
            label: 'Timesheet',
            barColor: LG_BG_THEME.WHITE_THEME,
            pressColor: LG_BG_THEME.WHITE_THEME,
        },
        {
            key: 'Message',
            icon: 'Message',
            label: 'Message',
            barColor: LG_BG_THEME.WHITE_THEME,
            pressColor: LG_BG_THEME.WHITE_THEME,
        },
        {
            key: 'Settings',
            icon: 'Settings',
            label: 'Settings',
            barColor: LG_BG_THEME.WHITE_THEME,
            pressColor: LG_BG_THEME.WHITE_THEME,
        }
    ]

    state = {
        ActiveTab: 'Home'
    }

    renderIcon = icon => ({ isActive }) => (
        <Image
            source={icon == "Home" ? require('../../../../Asset/Icons/Home_Icon.png') :
                icon == "Calendar" ? require('../../../../Asset/Icons/Calendar_Icon.png') :
                    icon == "Timesheet" ? require('../../../../Asset/Icons/Timesheet_Icon.png') :
                        icon == "Message" ? require('../../../../Asset/Icons/Message_Icon.png') :
                            require('../../../../Asset/Icons/settings.png')} style={{ width: width / 100 * 6, height: width / 100 * 6, tintColor: isActive ? LG_BG_THEME.APPTHEME_1 : LG_BG_THEME.WHITE_THEME, opacity: 0.9 }} />
    )


    renderTab = ({ tab, isActive }) => (
        <ShiftingTab
            backgroundColor={isActive ? LG_BG_THEME.WHITE_THEME : LG_BG_THEME.APPTHEME_1}
            isActive={isActive}
            key={tab.key}
            label={tab.label}
            //style={{backgroundColor:"red"}}
            labelStyle={{ color: isActive ? LG_BG_THEME.APPTHEME_1 : LG_BG_THEME.WHITE_THEME, fontFamily: fontFamily.Poppins_SemiBold, marginLeft: width / 100 * 1, textAlign: 'left' }}
            renderIcon={this.renderIcon(tab.icon)}
        />
    )

    //......Account Tab......//

    Account_Method(RouteName) {
        if (RouteName == "Edit_Settings") {
            this.props.navigation.navigate("Edit_Settings")
        } else if (RouteName == "Logout") {
            Alert.alert(
                'Confirmation..!',
                'Are you sure, You want to Logout ?',
                [
                    { text: 'YES', onPress: () => this.Login_Screen() },
                    { text: 'NO', style: 'cancel' },

                ],
                { cancelable: false }
            )
        } else {
            Snackbar.show({
                title: 'Server Underconstruction..!',
                duration: Snackbar.LENGTH_SHORT,
            });
        }

    }


    Login_Screen(){
        AsyncStorage.setItem('Cass_UserID', "0", () => {

        });
        AsyncStorage.setItem('Cass_RoleID', "0", () => {

        });
        this.props.navigation.navigate("Login_Screen")
    }


    Floating_Button() {

        if (this.state.ActiveTab == "Payments") {
            Snackbar.show({
                title: 'Server Underconstruction..!',
                duration: Snackbar.LENGTH_SHORT,
            });
        } else if (this.state.ActiveTab == "Businesses") {
            this.props.navigation.navigate("Add_Business")

        } else {
            this.props.navigation.navigate("Campaigns_Screen")
        }
    }

    Container_Method(RouteName) {
        if (RouteName == "Tab") {
            // this.setState({ ActiveTab: "Message" })
        } else {
            if (RouteName == "Timesheet_List") {
                this.props.navigation.navigate(RouteName, {
                    CalendarDate: "",
                });
            } else {
                this.props.navigation.navigate(RouteName)
            }
        }
    }

    Notifications_TabMethod(RouteName) {
        this.setState({ Notifications_Tab: RouteName })
    }

    Calender_Method(RouteName) {

        if (RouteName == "Add_Leave" || RouteName == "Add_Timesheet") {
            this.props.navigation.navigate(RouteName, {
                CalendarDate: this.state.Calendar_Date,
            });
        } else if (RouteName == "Jobs_List") {
            this.props.navigation.navigate(RouteName, {
                TimesheetDate: this.state.Timesheet_Date,
            });
        } else {
            this.props.navigation.navigate(RouteName)
        }

    }

    Message_Method() {

    }

    onDateChange(RouteName, Date_Index) {

        //var Current_Date = new Date(new Date().getTime() + (86400000))


        if (RouteName == "CALENDAR") {
            this.setState({
                Calendar_Date: Moment(Date_Index).format('YYYY-MM-DD'),
                CD_Year: Moment(Date_Index).format('YYYY'),
                CD_Month: Moment(Date_Index).format('MMMM'),
                CD_Date: Moment(Date_Index).format('DD')
            })
        } else {
            this.setState({
                Timesheet_Date: Moment(Date_Index).format('YYYY-MM-DD'),
                TD_Year: Moment(Date_Index).format('YYYY'),
                TD_Month: Moment(Date_Index).format('MMMM'),
                TD_Date: Moment(Date_Index).format('DD')
            })
        }
    }
    Container_Model(RouteName) {
        this.setState({ Info_Modal: RouteName })
    }

    onSwipe(gestureName, gestureState) {
        const { SWIPE_LEFT, SWIPE_RIGHT } = swipeDirections;
        this.setState({ gestureName: gestureName });
        switch (gestureName) {
            case SWIPE_RIGHT:

                if (this.state.Message_ListIndex >= 1) {
                    this.setState({ Message_ListIndex: --this.state.Message_ListIndex })
                } else {
                    Snackbar.show({
                        title: 'First Message..!',
                        duration: Snackbar.LENGTH_SHORT,
                    });
                }
                break;
            case SWIPE_LEFT:
                if (this.state.Message_ListIndex < 4) {
                    this.setState({ Message_ListIndex: ++this.state.Message_ListIndex })
                } else {
                    Snackbar.show({
                        title: 'Final Message..!',
                        duration: Snackbar.LENGTH_SHORT,
                    });
                }
                break;
        }
    }

    render() {

        const { Dashboard_Fetching } = this.state;

        var spinner = false;
        if (Dashboard_Fetching == true) {
            spinner = <Spinner visibility={true} />
        } else {
            spinner = false
        }

        const config = {
            velocityThreshold: 0.1,
            directionalOffsetThreshold: 50
        };

        return (
            <LinearGradient key="background" start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={[LG_BG_THEME.APPTHEME_BG_2, LG_BG_THEME.APPTHEME_1]} style={{ flex: 1, justifyContent: "center" }} >
                {spinner}

                <Mystatusbar />

                <View style={{ flex: 1, justifyContent: "center", backgroundColor: LG_BG_THEME.APPTHEME_1 }}>


                    {
                        this.state.ActiveTab == "Home" ?
                            <TouchableWithoutFeedback onPress={Keyboard.dismiss}>

                                <View style={{ flex: 1, }}>
                                    <AS_HeaderDesign
                                        Onpress_RightIcon={() => this.Container_Method("Notification_Screen")}
                                        Header_Text={"WELCOME"}
                                        RightIcon_Status={"welcome"}
                                        LeftIcon_Status={false}
                                    />

                                    <View style={{ flex: 0.5, backgroundColor: LG_BG_THEME.APPTHEME_1, }}>
                                        <View style={styles.Container_EP_1} />

                                        <View style={{ flex: 0.2, justifyContent: "center", alignItems: 'center', backgroundColor: LG_BG_THEME.APPTHEME_1, }}>
                                            <View style={{ height: width / 100 * 20, width: width / 100 * 20, borderRadius: width / 100 * 10, justifyContent: "center", backgroundColor: LG_BG_THEME.APPTHEME_BG, alignItems: 'center', borderColor: LG_BG_THEME.WHITE_THEME, borderWidth: width / 100 * 0.6 }}>
                                                <Image source={{ uri: this.state.User_ResponseArray.image }} style={{ width: width / 100 * 14, height: width / 100 * 14, }} />
                                            </View>
                                        </View>

                                        <View style={styles.Container_EP_1} />

                                        <View style={{ flex: 0.8, justifyContent: "center" }}>

                                            <View style={{ flex: 0.3, justifyContent: "center" }}>
                                                <View style={styles.Container_EP_1} />
                                                <Home_Usertext
                                                    ASB_Text={this.state.User_ResponseArray.username}
                                                />
                                                <Home_Usertext
                                                    ASB_Text={this.state.User_ResponseArray.department_name}
                                                />
                                            </View>
                                            <View style={styles.Container_EP_1} />

                                            <View style={{ flex: 0.7, justifyContent: "center" }}>
                                                <View style={{ flex: 0.3, justifyContent: "center", flexDirection: "row" }}>
                                                    <View style={{ flex: 0.15, justifyContent: "center", alignItems: "center" }}>
                                                        <Image source={require('../../../../Asset/Icons/Calendar_Icon.png')} style={{ width: width / 100 * 6, height: width / 100 * 6, tintColor: LG_BG_THEME.WHITE_THEME }} />
                                                    </View>
                                                    <View style={{ flex: 0.85, justifyContent: "center", alignItems: "flex-start" }}>
                                                        <Text numberOfLines={1} style={styles.container_WText}>{"Recent Timesheet"}</Text>
                                                    </View>
                                                </View>

                                                <View style={{ flex: 0.7, justifyContent: "center", marginLeft: width / 100 * 6, marginRight: width / 100 * 6 }}>
                                                    <Home_Timesheetscard
                                                        Card_BG={"#292929"}
                                                        CardHeader_1={"Wednesday"}
                                                        CardText_1={"4-March"}
                                                        CardHeader_2={"Thursday"}
                                                        CardText_2={"6-March"}
                                                        CardHeader_3={"Thursday"}
                                                        CardText_3={"7-March"}
                                                    />
                                                </View>
                                            </View>

                                        </View>
                                    </View>

                                    <View style={{ flex: 0.5, backgroundColor: LG_BG_THEME.APPTHEME_BG_2, }}>
                                        <View style={{ flex: 0.20, backgroundColor: LG_BG_THEME.APPTHEME_1, borderBottomLeftRadius: width / 100 * 10, borderBottomRightRadius: width / 100 * 10, }}>
                                            <View style={{ flex: 0.2, }} />

                                            <ViewAll_Design
                                                ViewAll_Method={() => this.Container_Method("Timesheet_List")}
                                                status={"Timesheet"}
                                                ViewText={"View All"}
                                                Text_BG={LG_BG_THEME.WHITE_THEME}
                                            />
                                            <View style={{ flex: 0.3 }} />

                                        </View>

                                        <View style={{ flex: 0.80, justifyContent: 'center', backgroundColor: LG_BG_THEME.APPTHEME_BG_2 }} >

                                            <View style={styles.Container_EP_1} />

                                            <Home_Headertext
                                                Home_Centertext={"MESSAGES"}
                                            />

                                            <View style={styles.Container_EP_2} />

                                            <View style={{ flex: 0.43, justifyContent: 'center', }}>


                                                {
                                                    this.state.Message_ListCount == 0 ?

                                                        <Home_Msgcard
                                                            CardList_Method={() => this.Message_Method()}
                                                            Card_BG={LG_BG_THEME.APPTHEME_1}
                                                            CardText_1={""}
                                                            CardText_2={"No Recent Message"}
                                                            CardText_Header3={""}
                                                            CardText_3={""}
                                                        />

                                                        :
                                                        <GestureRecognizer
                                                            onSwipe={(direction, state) => this.onSwipe(direction, state)}
                                                            config={config}>
                                                            <Home_Msgcard
                                                                CardList_Method={() => this.Message_Method()}
                                                                Card_BG={LG_BG_THEME.APPTHEME_1}
                                                                CardText_1={this.state.Msg_ResponseArray[this.state.Message_ListIndex].message}
                                                                CardText_2={Moment(this.state.Msg_ResponseArray[this.state.Message_ListIndex].sent_at).format('D-MMMM-YY') + " at " + Moment(this.state.Msg_ResponseArray[this.state.Message_ListIndex].sent_at).format("h A")}
                                                                CardText_Header3={""}
                                                                CardText_3={"-by " + this.state.Msg_ResponseArray[this.state.Message_ListIndex].first_name + " " + this.state.Msg_ResponseArray[this.state.Message_ListIndex].last_name}
                                                            />

                                                        </GestureRecognizer>


                                                }

                                            </View>

                                            <View style={{ flex: 0.15, justifyContent: "center", flexDirection: "row" }}>
                                                <View style={{ flex: 0.4, }} />
                                                <View style={{ flex: 0.2, justifyContent: "center", alignItems: "center", flexDirection: "row" }}>
                                                    <View style={{ flex: 0.05 }} />
                                                    <View style={{ flex: 0.3, justifyContent: "center", alignItems: "center" }}>
                                                        <Image source={require('../../../../Asset/Icons/Circle.png')} style={{ width: width / 100 * 2, height: width / 100 * 2, tintColor: LG_BG_THEME.APPTHEME_1 }} />
                                                    </View>
                                                    <View style={{ flex: 0.3, justifyContent: "center", alignItems: "center" }}>
                                                        <Image source={require('../../../../Asset/Icons/Circle.png')} style={{ width: width / 100 * 2, height: width / 100 * 2, tintColor: LG_BG_THEME.APPTHEME_GREY }} />
                                                    </View>
                                                    <View style={{ flex: 0.3, justifyContent: "center", alignItems: "center" }}>
                                                        <Image source={require('../../../../Asset/Icons/Circle.png')} style={{ width: width / 100 * 2, height: width / 100 * 2, tintColor: LG_BG_THEME.APPTHEME_GREY }} />
                                                    </View>
                                                    <View style={{ flex: 0.05 }} />
                                                </View>

                                                <View style={{ flex: 0.4, }} />

                                            </View>

                                            <ViewAll_Design
                                                ViewAll_Method={() => this.Container_Method("Tab")}
                                                status={"Msg"}
                                                ViewText={"View All"}
                                                Text_BG={"#010066"}
                                            />
                                            <View style={{ flex: 0.05 }} />
                                        </View>

                                    </View>

                                </View>
                            </TouchableWithoutFeedback>
                            : this.state.ActiveTab == "Calendar" ?

                                <View style={{ flex: 1 }}>
                                    <AS_HeaderDesign
                                        Onpress_RightIcon={() => this.Container_Method("Goback")}
                                        Header_Text={"CALENDAR"}
                                        RightIcon_Status={true}
                                        LeftIcon_Status={false}
                                    />

                                    <View style={{ flex: 0.15, backgroundColor: LG_BG_THEME.APPTHEME_1, justifyContent: 'center', flexDirection: 'row', }}>

                                        <View style={{ flex: 0.2, }} />

                                        <View style={{ flex: 0.6, justifyContent: 'center', flexDirection: 'row' }}>


                                            <View style={{ flex: 0.495, justifyContent: "center", alignItems: "center" }}>
                                                <Text style={{ fontSize: Platform.OS == "android" ? width / 100 * 10.2 : width / 100 * 10, fontFamily: fontFamily.Poppins_SemiBold, letterSpacing: width / 100 * 0.1, color: LG_BG_THEME.WHITE_THEME }}>{this.state.CD_Date}</Text>
                                            </View>

                                            <View style={{ flex: 0.01, backgroundColor: LG_BG_THEME.WHITE_THEME }} />
                                            <View style={{ flex: 0.495, justifyContent: "center", alignItems: "center" }}>
                                                <View style={{ flex: 0.1, justifyContent: "center", alignItems: "center" }} />

                                                <View style={{ flex: 0.4, justifyContent: "center", alignItems: "center" }}>
                                                    <Text style={{ fontSize: fontSize.ExtraLarge, fontFamily: fontFamily.Poppins_SemiBold, letterSpacing: width / 100 * 0.1, color: LG_BG_THEME.WHITE_THEME }}>{this.state.CD_Month}</Text>
                                                </View>

                                                <View style={{ flex: 0.4, justifyContent: "center", alignItems: "center" }}>
                                                    <Text style={{ fontSize: fontSize.ExtraLarge, fontFamily: fontFamily.Poppins_SemiBold , letterSpacing: width / 100 * 0.1, color: LG_BG_THEME.WHITE_THEME }}>{this.state.CD_Year}</Text>
                                                </View>

                                                <View style={{ flex: 0.1, justifyContent: "center", alignItems: "center" }} />
                                            </View>

                                        </View>

                                        <View style={{ flex: 0.2, }} />

                                    </View>
                                    <View style={{ flex: 0.05, backgroundColor: LG_BG_THEME.APPTHEME_BG_2, }}>
                                        <View style={{ flex: 1, backgroundColor: LG_BG_THEME.APPTHEME_1, borderBottomLeftRadius: width / 100 * 12, borderBottomRightRadius: width / 100 * 12, }} />
                                    </View>

                                    <View style={{ flex: 0.8, justifyContent: 'center', backgroundColor: LG_BG_THEME.APPTHEME_BG_2, }}>
                                        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
                                            <ScrollView showsVerticalScrollIndicator={false}>

                                                <View style={styles.Container_EP_2} />

                                                <View style={styles.Calendar_View}>

                                                    <CalendarPicker
                                                        startFromMonday={false}
                                                        allowRangeSelection={false}
                                                        selectedStartDate={this.state.Calendar_Date}
                                                        initialDate={new Date(new Date().getTime())}
                                                        minDate={new Date(new Date().getTime() - (86400000 * 30))}
                                                        maxDate={new Date(new Date().getTime() + (86400000 * 30))}
                                                        // weekdays={['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab', 'Dom']}
                                                        // months={['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']}
                                                        previousTitle="<"
                                                        nextTitle=">"
                                                        enableSwipe={true}
                                                        dayShape={"square"}
                                                        todayBackgroundColor={LG_BG_THEME.APPTHEME_1}
                                                        selectedDayColor={LG_BG_THEME.APPTHEME_2}
                                                        selectedDayTextColor={LG_BG_THEME.WHITE_THEME}
                                                        scaleFactor={375}
                                                        width={width / 100 * 70}
                                                        height={height / 100 * 50}
                                                        textStyle={{
                                                            fontFamily: fontFamily.Poppins_Regular,
                                                            color: LG_BG_THEME.APPTHEME_BLACK,
                                                        }}
                                                        onDateChange={(Date) => this.onDateChange("CALENDAR", Date)}
                                                    />
                                                </View>

                                                <View style={styles.Container_EP_2} />

                                                <CM_ButtonDesign
                                                    CMB_BuutonColourcode={LG_BG_THEME.APPTHEME_Blue}
                                                    onPress_BuutonView={() => this.Calender_Method("Add_Leave")}
                                                    CMB_TextHeader={"Add Leave"}
                                                />

                                                <View style={styles.Container_EP_1} />

                                                <CM_ButtonDesign
                                                    CMB_BuutonColourcode={LG_BG_THEME.APPTHEME_Blue}
                                                    onPress_BuutonView={() => this.Calender_Method("Add_Timesheet")}
                                                    CMB_TextHeader={"Add Timesheet"}
                                                />
                                                <View style={styles.Container_EP_1} />

                                            </ScrollView>
                                        </TouchableWithoutFeedback>

                                    </View>


                                </View>
                                : this.state.ActiveTab == "Timesheet" ?
                                    <View style={{ flex: 1 }}>
                                        <AS_HeaderDesign
                                            Onpress_RightIcon={() => this.Container_Method("Goback")}
                                            Header_Text={"TIMESHEETS"}
                                            RightIcon_Status={true}
                                            LeftIcon_Status={false}
                                        />

                                        <View style={{ flex: 0.15, backgroundColor: LG_BG_THEME.APPTHEME_1, justifyContent: 'center', flexDirection: 'row', }}>

                                            <View style={{ flex: 0.2, }} />

                                            <View style={{ flex: 0.6, justifyContent: 'center', flexDirection: 'row' }}>

                                                <View style={{ flex: 0.495, justifyContent: "center", alignItems: "center" }}>
                                                    <Text style={{ fontSize: Platform.OS == "android" ? width / 100 * 10.2 : width / 100 * 10, fontFamily: fontFamily.Poppins_SemiBold, letterSpacing: width / 100 * 0.1, color: LG_BG_THEME.WHITE_THEME }}>{this.state.TD_Date}</Text>
                                                </View>

                                                <View style={{ flex: 0.01, backgroundColor: LG_BG_THEME.WHITE_THEME }} />
                                                <View style={{ flex: 0.495, justifyContent: "center", alignItems: "center" }}>
                                                    <View style={{ flex: 0.1, justifyContent: "center", alignItems: "center" }} />

                                                    <View style={{ flex: 0.4, justifyContent: "center", alignItems: "center" }}>
                                                        <Text style={{ fontSize: fontSize.ExtraLarge, fontFamily: fontFamily.Poppins_SemiBold, letterSpacing: width / 100 * 0.1, color: LG_BG_THEME.WHITE_THEME }}>{this.state.TD_Year}</Text>
                                                    </View>

                                                    <View style={{ flex: 0.4, justifyContent: "center", alignItems: "center" }}>
                                                        <Text style={{ fontSize: fontSize.ExtraLarge, fontFamily: fontFamily.Poppins_SemiBold, letterSpacing: width / 100 * 0.1, color: LG_BG_THEME.WHITE_THEME }}>{this.state.TD_Month}</Text>
                                                    </View>

                                                    <View style={{ flex: 0.1, justifyContent: "center", alignItems: "center" }} />
                                                </View>
                                            </View>

                                            <View style={{ flex: 0.2, }} />

                                        </View>

                                        <View style={{ flex: 0.05, backgroundColor: LG_BG_THEME.APPTHEME_BG_2, }}>
                                            <View style={{ flex: 1, backgroundColor: LG_BG_THEME.APPTHEME_1, borderBottomLeftRadius: width / 100 * 12, borderBottomRightRadius: width / 100 * 12, }} />
                                        </View>
                                        <View style={{ flex: 0.8, justifyContent: 'center', backgroundColor: LG_BG_THEME.APPTHEME_BG_2 }}>
                                            <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
                                                <ScrollView showsVerticalScrollIndicator={false}>

                                                    <View style={styles.Container_EP_4} />

                                                    <View style={styles.Calendar_View}>

                                                        <CalendarPicker
                                                            startFromMonday={false}
                                                            allowRangeSelection={false}
                                                            selectedStartDate={this.state.Timesheet_Date}
                                                            initialDate={new Date(new Date().getTime())}
                                                            minDate={new Date(new Date().getTime() - (86400000 * 30))}
                                                            maxDate={new Date(new Date().getTime() + (86400000 * 30))}
                                                            // weekdays={['Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sab', 'Dom']}
                                                            // months={['Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho', 'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro']}
                                                            previousTitle="<"
                                                            nextTitle=">"
                                                            enableSwipe={true}
                                                            dayShape={"square"}
                                                            todayBackgroundColor={LG_BG_THEME.APPTHEME_1}
                                                            selectedDayColor={LG_BG_THEME.APPTHEME_2}
                                                            selectedDayTextColor={LG_BG_THEME.WHITE_THEME}
                                                            scaleFactor={375}
                                                            width={width / 100 * 70}
                                                            height={height / 100 * 50}
                                                            textStyle={{
                                                                fontFamily: fontFamily.Poppins_Regular,
                                                                color: LG_BG_THEME.APPTHEME_BLACK,
                                                            }}
                                                            onDateChange={(Date) => this.onDateChange("TIMESHEETS", Date)}
                                                        />
                                                    </View>


                                                    <View style={styles.Container_EP_4} />

                                                    <CM_ButtonDesign
                                                        CMB_BuutonColourcode={LG_BG_THEME.APPTHEME_Blue}
                                                        onPress_BuutonView={() => this.Calender_Method("Jobs_List")}
                                                        CMB_TextHeader={"Jobs"}
                                                    />
                                                    <View style={styles.Container_EP_1} />

                                                </ScrollView>
                                            </TouchableWithoutFeedback>

                                        </View>


                                    </View>
                                    : this.state.ActiveTab == "Message" ?

                                        <View style={{ flex: 1, backgroundColor: LG_BG_THEME.APPTHEME_BG_2 }}>
                                            <AS_HeaderDesign
                                                Onpress_RightIcon={() => this.Container_Model(true)}
                                                Header_Text={this.state.Notifications_Tab.toUpperCase()}
                                                RightIcon_Status={"Info"}
                                                LeftIcon_Status={false}
                                            />

                                            <View style={{ flex: 0.02 }} />
                                            <View style={styles.Container_EP_2} />

                                            <View style={{ flex: 0.08, justifyContent: 'center', flexDirection: "row" }}>
                                                <TouchableOpacity onPress={() => this.Notifications_TabMethod("Messages")} style={this.state.Notifications_Tab == "Messages" ? styles.Container_ActiveTabView : styles.Container_TabView}>
                                                    <Text style={styles.container_TabText}>{"Messages"}</Text>
                                                </TouchableOpacity>

                                                <View style={{ flex: 0.02, justifyContent: 'center' }} />

                                                <TouchableOpacity onPress={() => this.Notifications_TabMethod("Notifications")} style={this.state.Notifications_Tab == "Notifications" ? styles.Container_ActiveTabView : styles.Container_TabView}>
                                                    <Text style={styles.container_TabText}>{"Notifications"}</Text>
                                                </TouchableOpacity>
                                            </View>

                                            <View style={styles.Container_EP_2} />
                                            <View style={{ flex: 0.9, marginTop: width / 100 * 2 }}>
                                                {this.state.Notifications_Tab == "Messages" ?
                                                    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>

                                                        {this.state.Msg_ResponseArray.length == 0 ?
                                                            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                                                <Text style={styles.container_EmptyText}>{"No Message Found..!"}</Text>
                                                            </View>
                                                            :
                                                            <FlatList style={{ flex: 1, }}
                                                                data={this.state.Msg_ResponseArray}
                                                                showsVerticalScrollIndicator={false}
                                                                keyExtractor={(item, index) => item.key}
                                                                renderItem={({ item, index }) =>

                                                                    <MsgCardlist_Design
                                                                        CardList_Method={() => this.Message_Method()}
                                                                        Card_BG={"transparent"}
                                                                        CardText_1={item.first_name + " " + item.last_name}
                                                                        CardText_2={item.message}
                                                                        CardText_Header3={"Date : "}
                                                                        CardText_3={Moment(item.sent_at).format('D-MMMM-YY') + " at " + Moment(item.sent_at).format("h A")}
                                                                    />
                                                                }
                                                            />
                                                        }

                                                    </TouchableWithoutFeedback>
                                                    :
                                                    <TouchableWithoutFeedback onPress={Keyboard.dismiss}>
                                                        {this.state.Notify_ResponseArray.length == 0 ?
                                                            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                                                <Text style={styles.container_EmptyText}>{"No Notification Found..!"}</Text>
                                                            </View>
                                                            :
                                                            <FlatList style={{ flex: 1, }}
                                                                data={this.state.Notify_ResponseArray.slice(0, 5)}
                                                                showsVerticalScrollIndicator={false}
                                                                keyExtractor={(item, index) => item.key}
                                                                renderItem={({ item, index }) =>

                                                                    <CardList_Design
                                                                        CardList_Method={() => this.Message_Method()}
                                                                        Card_BG={item.dept_super_admin_status == "1" && item.dept_admin_status == "0" && item.finance_status == "0" && item.engineer_status == "0" ? Notify_THEME.AW_SUPERADMIN :
                                                                            item.dept_super_admin_status == "2" && item.dept_admin_status == "1" && item.finance_status == "0" && item.engineer_status == "0" ? Notify_THEME.AW_ADMIN :
                                                                                item.dept_super_admin_status == "2" && item.dept_admin_status == "2" && item.finance_status == "2" && item.engineer_status == "0" ? Notify_THEME.AW_FINANCE :
                                                                                    item.dept_super_admin_status == "2" && item.dept_admin_status == "2" && item.finance_status == "2" && item.engineer_status == "0" ? Notify_THEME.AW_APPROVED : Notify_THEME.AW_REJECTED}
                                                                        CardText_Header1={"Job No : "}
                                                                        CardText_1={item.job_no}
                                                                        CardText_Header2={"Status : "}
                                                                        CardText_2={item.notify_message}
                                                                        CardText_Header3={"By : "}
                                                                        CardText_3={item.submitter_name}
                                                                    />
                                                                }

                                                            />
                                                        }
                                                    </TouchableWithoutFeedback>

                                                }
                                            </View>
                                        </View>

                                        :

                                        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>

                                            <View style={{ flex: 1 }}>
                                                <AS_HeaderDesign
                                                    Onpress_RightIcon={() => this.Container_Method("Goback")}
                                                    Header_Text={"SETTINGS"}
                                                    RightIcon_Status={true}
                                                    LeftIcon_Status={false}
                                                />

                                                <View style={{ flex: 0.4, backgroundColor: LG_BG_THEME.APPTHEME_1, }}>
                                                    <View style={styles.Container_EP_4} />

                                                    <View style={{ flex: 0.3, justifyContent: "center", alignItems: 'center', backgroundColor: LG_BG_THEME.APPTHEME_1, }}>

                                                        <View style={{ height: width / 100 * 20, width: width / 100 * 20, borderRadius: width / 100 * 10, justifyContent: "center", backgroundColor: LG_BG_THEME.APPTHEME_BG, alignItems: 'center', borderColor: LG_BG_THEME.WHITE_THEME, borderWidth: width / 100 * 0.6 }}>
                                                            <Image source={{ uri: this.state.User_ResponseArray.image }} style={{ width: width / 100 * 14, height: width / 100 * 14, }} />
                                                        </View>

                                                    </View>


                                                    <View style={{ flex: 0.7, marginLeft: width / 100 * 4, marginRight: width / 100 * 4 }}>

                                                        <View style={styles.Container_EP_2} />
                                                        <AS_TextView
                                                            ASB_Text={this.state.User_ResponseArray.username}
                                                        />
                                                        <AS_TextView
                                                            ASB_Text={this.state.User_ResponseArray.department_name}
                                                        />
                                                        <AS_TextView
                                                            ASB_Text={this.state.User_ResponseArray.email}
                                                        />
                                                        <View style={styles.Container_EP_2} />
                                                    </View>
                                                </View>

                                                <View style={{ flex: 0.1, backgroundColor: LG_BG_THEME.APPTHEME_BG_2, justifyContent: "center" }}>
                                                    <View style={{ flex: 1, backgroundColor: LG_BG_THEME.APPTHEME_1, borderBottomLeftRadius: width / 100 * 12, borderBottomRightRadius: width / 100 * 12, justifyContent: "center", alignItems: "center", flexDirection: 'row' }}>
                                                        <View style={{ flex: 0.7 }} />
                                                        <TouchableOpacity onPress={() => this.Account_Method("Edit_Settings")} style={{ flex: 0.3, justifyContent: 'center', flexDirection: 'row' }}>
                                                            <View style={{ flex: 0.6, justifyContent: 'center', alignItems: 'flex-end' }}>
                                                                <Text numberOfLines={1} style={styles.container_EditText}>{"Edit"}</Text>
                                                            </View>

                                                            <View style={{ flex: 0.4, justifyContent: 'center', alignItems: "center" }}>
                                                                <Image source={require('../../../../Asset/Icons/Edit_Icon.png')} style={{ width: width / 100 * 3.5, height: width / 100 * 3.5, tintColor: LG_BG_THEME.WHITE_THEME, }} />
                                                            </View>
                                                        </TouchableOpacity>

                                                    </View>
                                                </View>
                                                <View style={{ flex: 0.5, backgroundColor: LG_BG_THEME.APPTHEME_BG_2, }} >
                                                    <View style={styles.Container_EP_2} />

                                                    <AS_SidebardDesign
                                                        AS_SidebardMethod={() => this.Account_Method("Terms and conditions")}
                                                        AS_SidebardText={"Terms and conditions"}
                                                    />

                                                    <AS_SidebardDesign
                                                        AS_SidebardMethod={() => this.Account_Method("Support")}
                                                        AS_SidebardText={"Support"}
                                                    />

                                                    <AS_SidebardDesign
                                                        AS_SidebardMethod={() => this.Account_Method("Logout")}
                                                        AS_SidebardText={"Logout"}
                                                    />
                                                </View>

                                            </View>
                                        </TouchableWithoutFeedback>
                    }


                    <BottomNavigation
                        ActiveTab={this.state.ActiveTab}
                        onTabPress={newTab => this.setState({ ActiveTab: newTab.key })}
                        renderTab={this.renderTab}
                        tabs={this.tabs}
                    />


                </View>

                <Modal
                    animationType='slide'
                    transparent={true}
                    visible={this.state.Info_Modal}
                    animationType="slide"
                    onRequestClose={() => { this.setState({ Info_Modal: false }) }}>

                    <View style={{ flex: 1, justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.5)' }}>
                        <View style={{ height: "100%", justifyContent: 'center', alignItems: 'center', backgroundColor: 'transparent' }}>
                            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', borderRadius: width / 100 * 2, flexDirection: "row" }}>

                                <View style={{ flex: 0.1, }} />
                                <View style={{ flex: 0.8, justifyContent: 'center' }}>

                                    <View style={{ height: width / 100 * 12, justifyContent: 'center', alignSelf: 'center', backgroundColor: LG_BG_THEME.APPTHEME_1, borderTopLeftRadius: width / 100 * 2, borderTopRightRadius: width / 100 * 2, flexDirection: 'row' }}>
                                        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                            <Text numberOfLines={1} style={{ fontSize: fontSize.Medium, fontFamily: fontFamily.Poppins_SemiBold, letterSpacing: width / 100 * 0.1, color: color.Font_Whitecolor, textAlign: "center" }}>{"COLOUR INFO"}</Text>
                                        </View>
                                    </View>

                                    <View style={{ height: width / 100 * 70, justifyContent: 'center', backgroundColor: LG_BG_THEME.WHITE_THEME, }}>

                                        <View style={styles.Container_EP_2} />

                                        <Modal_Text
                                            Modal_Infotext={"Awaiting Dept Super Admin..!"}
                                            Modal_InfoBG={Notify_THEME.AW_SUPERADMIN}
                                        />

                                        <View style={styles.Container_EP_2} />

                                        <Modal_Text
                                            Modal_Infotext={"Awaiting Dept Admin..!"}
                                            Modal_InfoBG={Notify_THEME.AW_ADMIN}
                                        />

                                        <View style={styles.Container_EP_2} />

                                        <Modal_Text
                                            Modal_Infotext={"Awaiting Finance Dept..!"}
                                            Modal_InfoBG={Notify_THEME.AW_FINANCE}
                                        />

                                        <View style={styles.Container_EP_2} />

                                        <Modal_Text
                                            Modal_Infotext={"Timesheets Approved..!"}
                                            Modal_InfoBG={Notify_THEME.AW_APPROVED}
                                        />

                                        <View style={styles.Container_EP_2} />

                                        <Modal_Text
                                            Modal_Infotext={"Timesheets Rejected..!"}
                                            Modal_InfoBG={Notify_THEME.AW_REJECTED}
                                        />

                                        <View style={styles.Container_EP_2} />

                                    </View>

                                    <View style={{ height: width / 100 * 12, justifyContent: 'center', alignSelf: 'center', backgroundColor: LG_BG_THEME.APPTHEME_1, borderBottomLeftRadius: width / 100 * 2, borderBottomRightRadius: width / 100 * 2, flexDirection: 'row' }}>
                                        <TouchableOpacity onPress={() => this.Container_Model(false)} style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                            <Text numberOfLines={1} style={{ fontSize: fontSize.Medium, fontFamily: fontFamily.Poppins_Regular, letterSpacing: width / 100 * 0.1, color: color.Font_Whitecolor, textAlign: "center", }}>{"Cancel"}</Text>
                                        </TouchableOpacity>
                                    </View>
                                </View>

                                <View style={{ flex: 0.1, }} />

                            </View>

                        </View>
                    </View>
                </Modal>
            </LinearGradient>

        )
    }

}


const styles = StyleSheet.create({

    container_Text: {
        fontSize: fontSize.lightMedium,
        fontFamily: fontFamily.Poppins_Regular,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.WHITE_THEME,
        marginLeft: width / 100 * 2
    },
    container_EditText:{
        fontSize: fontSize.lightMedium,
        fontFamily: fontFamily.Poppins_SemiBold,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.WHITE_THEME,
        marginLeft: width / 100 * 2
    },
    container_TabText: {
        fontSize: fontSize.Medium,
        fontFamily: fontFamily.Poppins_Bold,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.APPTHEME_BLACK,
        marginLeft: width / 100 * 2,
    },
    container_EmptyText: {
        fontSize: fontSize.Medium,
        fontFamily: fontFamily.Poppins_Bold,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.APPTHEME_BLACK,
        marginLeft: width / 100 * 2,
    },
    container_WText: {
        fontSize: fontSize.Medium,
        fontFamily: fontFamily.Poppins_SemiBold,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.WHITE_THEME,
        textAlign: "auto",
        marginRight: width / 100 * 5
    },
    Container_EP_1: {
        height: height / 100 * 1
    },
    Container_EP_2: {
        height: height / 100 * 2
    },
    Container_EP_4: {
        height: height / 100 * 4
    },
    Container_EP_8: {
        height: height / 100 * 8
    },
    Container_EP_12: {
        height: height / 100 * 12
    },
    Container_ActiveTabView: {
        flex: 0.49, justifyContent: 'center', alignItems: 'center',
        backgroundColor: LG_BG_THEME.WHITE_THEME,
        elevation: Platform.OS == "android" ? width / 100 * 1 : width / 100 * 0.1,
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.2,
        shadowColor: LG_BG_THEME.APPTHEME_1,
        borderBottomColor: LG_BG_THEME.APPTHEME_1,
        borderBottomWidth: width / 100 * 0.6
    },
    Container_TabView: {
        flex: 0.49, justifyContent: 'center', alignItems: 'center',
        backgroundColor: LG_BG_THEME.WHITE_THEME,
        elevation: Platform.OS == "android" ? width / 100 * 1 : width / 100 * 0.1,
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.2,
        shadowColor: LG_BG_THEME.APPTHEME_1
    },
    Container_TimesheetHeader: {
        flex: 0.49,
        justifyContent: 'center',
        alignItems: 'center',

    },
    Calendar_View: {
        height: height / 100 * 40,
        justifyContent: 'center',
        backgroundColor: "#EFEFEF",
        marginLeft: width / 100 * 10,
        marginRight: width / 100 * 10,
        marginTop: width / 100 * 2, marginBottom: width / 100 * 2,
        elevation: Platform.OS == "android" ? width / 100 * 1 : width / 100 * 0.2,
        shadowOffset: { width: 2, height: 2 },
        shadowOpacity: 0.2,
        shadowColor: LG_BG_THEME.APPTHEME_1,
    }



});

const mapStateToProps = (state) => {
    return {
        CommonReducer: state.CommonReducer
    };
}

const mapDispatchToProps = (dispatch) => {
    return {
        NotifyInfo_Action: (Notify_Response) => { dispatch(NotifyInfo_Action(Notify_Response)); },
        UserInfo_Action: (User_Response) => { dispatch(UserInfo_Action(User_Response)); },
    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Dashboard);
