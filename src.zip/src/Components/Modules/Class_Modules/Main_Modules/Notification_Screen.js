import React, { Component, PureComponent } from 'react'
import {
    StyleSheet, Text, Keyboard, AsyncStorage, FlatList,
    View, TouchableOpacity, Image, SafeAreaView, ImageBackground, BackHandler, Alert, Platform, Modal, TextInput, ScrollView, TouchableWithoutFeedback
} from 'react-native'
import { color, width, fontSize, fontFamily, height, LG_BG_THEME, Notify_THEME } from '../../../Constants/fontsAndColors'
import { Container, Content, connect, Picker, Header, LinearGradient, Snackbar, Splash_screen } from '../../../../Asset/Libraries/NpmList';
import { Mystatusbar } from '../../../../Asset/Libraries/index'

import Sample_json from '../Extra_Modules/Screenlist.json'

import { AS_HeaderDesign } from '../../CommonView_Modules/AS_HeaderDesign'
import { CardList_Design } from '../../CommonView_Modules/CardList_Design'
import { Modal_Text } from '../../CommonView_Modules/Modal_Text'


class Notification_Screen extends Component {

    constructor(props) {
        super(props);
        this.state = {
            Notify_ResponseArray: [],
            Info_Modal: false
        };

    }

    componentDidMount() {
        const { NotifyInfo_Response } = this.props.CommonReducer
        this.setState({
           Notify_ResponseArray: NotifyInfo_Response
        })
    }



    Container_Method(RouteName) {
        if (RouteName == "Goback") {
            this.props.navigation.goBack()
        } else {
            Snackbar.show({
                title: 'Server Underconstruction..!',
                duration: Snackbar.LENGTH_SHORT,
            });
        }

    }

    Container_Model(RouteName) {
        this.setState({ Info_Modal: RouteName })
    }
    render() {


        return (
            <LinearGradient key="background" start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={[LG_BG_THEME.APPTHEME_BG_2, LG_BG_THEME.APPTHEME_BG_2]} style={{ flex: 1, justifyContent: "center" }} >

                <Mystatusbar />
                <View style={{ flex: 1 }}>
                    <AS_HeaderDesign
                        Onpress_LeftIcon={() => this.Container_Method("Goback")}
                        Onpress_RightIcon={() => this.Container_Model(true)}
                        Header_Text={"NOTIFICATIONS"}
                        RightIcon_Status={"Info"}
                        LeftIcon_Status={true}
                    />

                    <View style={{ flex: 0.05 }} />

                    <View style={{ flex: 0.95, marginTop: width / 100 * 2 }}>
                        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>

                            {this.state.Notify_ResponseArray.length == 0 ?
                                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                    <Text style={styles.container_EmptyText}>{"No Notification Found..!"}</Text>
                                </View>
                                :
                                <FlatList style={{ flex: 1, }}
                                    data={this.state.Notify_ResponseArray}
                                    showsVerticalScrollIndicator={false}
                                    keyExtractor={(item, index) => item.key}
                                    renderItem={({ item, index }) =>
                                        <CardList_Design
                                            CardList_Method={() => this.Container_Method(item)}
                                            Card_BG={item.dept_super_admin_status == "1" && item.dept_admin_status == "0" && item.finance_status == "0" && item.engineer_status == "0" ? Notify_THEME.AW_SUPERADMIN :
                                                item.dept_super_admin_status == "2" && item.dept_admin_status == "1" && item.finance_status == "0" && item.engineer_status == "0" ? Notify_THEME.AW_ADMIN :
                                                    item.dept_super_admin_status == "2" && item.dept_admin_status == "2" && item.finance_status == "2" && item.engineer_status == "0" ? Notify_THEME.AW_FINANCE :
                                                        item.dept_super_admin_status == "2" && item.dept_admin_status == "2" && item.finance_status == "2" && item.engineer_status == "0" ? Notify_THEME.AW_APPROVED : Notify_THEME.AW_REJECTED}
                                            CardText_Header1={"Job No : "}
                                            CardText_1={item.job_no}
                                            CardText_Header2={"Status : "}
                                            CardText_2={item.notify_message}
                                            CardText_Header3={"By : "}
                                            CardText_3={item.submitter_name}
                                        />
                                    }
                                />
                            }
                        </TouchableWithoutFeedback>


                    </View>
                </View>

                <Modal
                    animationType='slide'
                    transparent={true}
                    visible={this.state.Info_Modal}
                    animationType="slide"
                    onRequestClose={() => { this.setState({ Info_Modal: false }) }}>

                    <View style={{ flex: 1, justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.5)' }}>
                        <View style={{ height: "100%", justifyContent: 'center', alignItems: 'center', backgroundColor: 'transparent' }}>
                            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', borderRadius: width / 100 * 2, flexDirection: "row" }}>

                                <View style={{ flex: 0.1, }} />
                                <View style={{ flex: 0.8, justifyContent: 'center' }}>

                                    <View style={{ height: width / 100 * 12, justifyContent: 'center', alignSelf: 'center', backgroundColor: LG_BG_THEME.APPTHEME_1, borderTopLeftRadius: width / 100 * 2, borderTopRightRadius: width / 100 * 2, flexDirection: 'row' }}>
                                        <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                            <Text numberOfLines={1} style={{ fontSize: fontSize.Medium, fontFamily: fontFamily.Poppins_Regular, letterSpacing: width / 100 * 0.1, color: color.Font_Whitecolor, textAlign: "center" }}>{"COLOUR INFO"}</Text>
                                        </View>
                                    </View>

                                    <View style={{ height: width / 100 * 70, justifyContent: 'center', backgroundColor: LG_BG_THEME.WHITE_THEME, }}>

                                        <View style={styles.Container_EP_2} />

                                        <Modal_Text
                                            Modal_Infotext={"Awaiting Dept Super Admin..!"}
                                            Modal_InfoBG={Notify_THEME.AW_SUPERADMIN}
                                        />

                                        <View style={styles.Container_EP_2} />

                                        <Modal_Text
                                            Modal_Infotext={"Awaiting Dept Admin..!"}
                                            Modal_InfoBG={Notify_THEME.AW_ADMIN}
                                        />

                                        <View style={styles.Container_EP_2} />

                                        <Modal_Text
                                            Modal_Infotext={"Awaiting Finance Dept..!"}
                                            Modal_InfoBG={Notify_THEME.AW_FINANCE}
                                        />

                                        <View style={styles.Container_EP_2} />

                                        <Modal_Text
                                            Modal_Infotext={"Timesheets Approved..!"}
                                            Modal_InfoBG={Notify_THEME.AW_APPROVED}
                                        />

                                        <View style={styles.Container_EP_2} />

                                        <Modal_Text
                                            Modal_Infotext={"Timesheets Rejected..!"}
                                            Modal_InfoBG={Notify_THEME.AW_REJECTED}
                                        />

                                        <View style={styles.Container_EP_2} />

                                    </View>

                                    <View style={{ height: width / 100 * 12, justifyContent: 'center', alignSelf: 'center', backgroundColor: LG_BG_THEME.APPTHEME_1, borderBottomLeftRadius: width / 100 * 2, borderBottomRightRadius: width / 100 * 2, flexDirection: 'row' }}>

                                        <TouchableOpacity onPress={() => this.Container_Model(false)} style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                            <Text numberOfLines={1} style={{ fontSize: fontSize.Medium, fontFamily: fontFamily.Poppins_Regular, letterSpacing: width / 100 * 0.1, color: color.Font_Whitecolor, textAlign: "center" }}>{"Cancel"}</Text>
                                        </TouchableOpacity>

                                    </View>
                                </View>

                                <View style={{ flex: 0.1, }} />

                            </View>

                        </View>
                    </View>
                </Modal>
            </LinearGradient>

        )
    }

}


const styles = StyleSheet.create({

    Container_EP_2: {
        height: height / 100 * 2
    },
    container_EmptyText: {
        fontSize: fontSize.Medium,
        fontFamily: fontFamily.Poppins_Bold,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.APPTHEME_BLACK,
        marginLeft: width / 100 * 2,
    },

});

const mapStateToProps = (state) => {
    return {
        CommonReducer: state.CommonReducer
    };
}

const mapDispatchToProps = (dispatch) => {
    return {
        // DashboardAction : () => { dispatch(DashboardAction()) },

    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Notification_Screen);
