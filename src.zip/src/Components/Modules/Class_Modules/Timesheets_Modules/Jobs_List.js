import React, { Component, PureComponent } from 'react'
import {
    StyleSheet, Text, Keyboard, AsyncStorage, FlatList,
    View, TouchableOpacity, Image, SafeAreaView, ImageBackground, BackHandler, Alert, Platform, Modal, TextInput, ScrollView, TouchableWithoutFeedback
} from 'react-native'
import { color, width, fontSize, fontFamily, height, LG_BG_THEME } from '../../../Constants/fontsAndColors'
import { Container, Content, connect, Picker, Header, LinearGradient, Snackbar, Splash_screen, Moment } from '../../../../Asset/Libraries/NpmList';
import { Mystatusbar } from '../../../../Asset/Libraries/index'

import Sample_json from '../Extra_Modules/Screenlist.json'

import { AS_HeaderDesign } from '../../CommonView_Modules/AS_HeaderDesign'
import { Card_Joblist } from '../../CommonView_Modules/Card_Joblist'

import { Basic_Auth, Cass_APIKEY, Job_list } from '././../../../Config/Server'
import { Spinner } from '../../../Config/Spinner';

class Jobs_List extends Component {

    constructor(props) {
        super(props);
        this.state = {
            CassUserID: "",
            CassRoleID: "",
            Jobs_ResponseArray: [],
            StartDate: "",
            Dashboard_Fetching: false

        };

    }

    componentDidMount() {

        AsyncStorage.getItem("Cass_UserID", (error, Token_Result) => {
            if (Token_Result != "0" || Token_Result != null) {
                AsyncStorage.getItem("Cass_RoleID", (error, Token_RoleID) => {
                    if (Token_RoleID != "0" || Token_RoleID != null) {
                        this.setState({ CassUserID: Token_Result, CassRoleID: Token_RoleID, Dashboard_Fetching: true }, () => this._fetchdata(Token_Result, Token_RoleID));
                    }
                })
            }
        })
        const { state } = this.props.navigation;
        let Calendar_Date = state.params.CalendarDate

        this.setState({
            StartDate: Moment(Calendar_Date).format('DD-MMMM-YY')
        })
    }

    async _fetchdata(Token_Result, Token_RoleID) {
        const JobsInfo_Response = await this._fetch_JobsInfo(Token_Result, Token_RoleID);

        try {
            this.setState({
                Jobs_ResponseArray: JobsInfo_Response.Job_Info,
                Dashboard_Fetching: false
            })
        } catch (err) {
            this.setState({ Dashboard_Fetching: false });
        }
    }

    _fetch_JobsInfo(Token_Result, Token_RoleID) {
        return new Promise((resolve, reject) => {
            let JobsInfo_URL = Job_list + Token_Result + "&user_role=" + Token_RoleID + Cass_APIKEY;
            fetch(JobsInfo_URL, {
                method: 'GET',
                headers: Basic_Auth
            })
                .then((response) => response.json())
                .then((Jsonresponse) => {
                    let Job_Info = ""
                    if (Jsonresponse.status != false) {
                        Job_Info = Jsonresponse
                        resolve({ Job_Info });
                    } else {
                        reject(Job_Info)
                    }
                })
                .catch((error) => {
                    this.setState({ Dashboard_Fetching: false });
                    Snackbar.show({
                        title: "Internal Server Error..!",
                        duration: Snackbar.LENGTH_SHORT,
                    });
                });
        });
    }
    Container_Method(RouteName) {
        if (RouteName == "Goback") {
            this.props.navigation.goBack()
        } else {

            if (RouteName == "Timesheet_List") {
                this.props.navigation.navigate(RouteName, {
                    CalendarDate: this.state.StartDate,
                });
            } else {
                this.props.navigation.navigate(RouteName)

            }

            // Snackbar.show({
            //     title: 'Server Underconstruction..!',
            //     duration: Snackbar.LENGTH_SHORT,
            // });
        }

    }

    render() {

        const { Dashboard_Fetching } = this.state;

        var spinner = false;
        if (Dashboard_Fetching == true) {
            spinner = <Spinner visibility={true} />
        } else {
            spinner = false
        }

        return (
            <LinearGradient key="background" start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={[LG_BG_THEME.APPTHEME_BG_2, LG_BG_THEME.APPTHEME_BG_2]} style={{ flex: 1, justifyContent: "center" }} >
                {spinner}

                <Mystatusbar />
                <View style={{ flex: 1 }}>
                    <AS_HeaderDesign
                        Onpress_LeftIcon={() => this.Container_Method("Goback")}
                        Onpress_RightIcon={() => this.Container_Method("Goback")}
                        Header_Text={"JOBS"}
                        RightIcon_Status={true}
                        LeftIcon_Status={true}
                    />

                    <View style={{ flex: 0.02 }} />
                    <View style={styles.Container_EP_2} />

                    <View style={{ flex: 0.08, justifyContent: 'center', flexDirection: "row" }}>

                        <View style={{ flexDirection: "row", flex: 0.495, justifyContent: 'center', alignItems: 'center' }}>

                            <View style={{ flex: 0.3, justifyContent: 'center', alignItems: "flex-end" }}>
                                <Image source={require('../../../../Asset/Icons/Calendar_Icon.png')} style={{ width: width / 100 * 3.5, height: width / 100 * 3.5, tintColor: LG_BG_THEME.APPTHEME_BLACK, }} />
                            </View>
                            <View style={{ flex: 0.7, justifyContent: 'center', alignItems: "flex-start" }}>
                                <Text style={styles.container_TabText}>{this.state.StartDate}</Text>
                            </View>
                        </View>


                        <View style={{ flex: 0.02, justifyContent: 'center' }} />

                        <View style={styles.Container_TimesheetHeader}>
                            <Text style={styles.container_TabText}>{"Total Jobs - " + this.state.Jobs_ResponseArray.length}</Text>
                        </View>
                    </View>

                    <View style={{ flex: 0.9, marginTop: width / 100 * 2, marginLeft: width / 100 * 6, marginRight: width / 100 * 6 }}>
                        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>


                            {this.state.Jobs_ResponseArray.length == 0 ?
                                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                    <Text style={styles.container_EmptyText}>{"No Jobs Found..!"}</Text>
                                </View>
                                :
                                <FlatList style={{ flex: 1, }}
                                    data={this.state.Jobs_ResponseArray}
                                    showsVerticalScrollIndicator={false}
                                    keyExtractor={(item, index) => item.key}
                                    renderItem={({ item, index }) =>

                                        <Card_Joblist
                                            CardList_AMORE={() => this.Container_Method()}
                                            CardList_VAll={() => this.Container_Method("Timesheet_List")}
                                            Card_BG={LG_BG_THEME.WHITE_THEME}
                                            CardText_Header1={"Job No : "}
                                            CardText_1={item.job_no}
                                            CardText_Header2={"Exchange : "}
                                            CardText_2={item.exchange}
                                            CardText_Header3={"Department : "}
                                            CardText_3={item.department_name}
                                            CardTimesheet_Count={"Timesheets " + item.jobs}
                                        />
                                    }
                                />
                            }


                        </TouchableWithoutFeedback>


                    </View>
                </View>
            </LinearGradient>

        )
    }

}


const styles = StyleSheet.create({

    container_TabText: {
        fontSize: fontSize.lightMedium,
        fontFamily: fontFamily.Poppins_Regular,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.APPTHEME_BLACK,
        marginLeft: width / 100 * 2,
    },
    Container_EP_1: {
        height: height / 100 * 1
    },
    Container_EP_2: {
        height: height / 100 * 2
    },
    Container_EP_4: {
        height: height / 100 * 4
    },

    Container_TimesheetHeader: {
        flex: 0.49,
        justifyContent: 'center',
        alignItems: 'center',

    },
    container_EmptyText: {
        fontSize: fontSize.Medium,
        fontFamily: fontFamily.Poppins_Bold,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.APPTHEME_BLACK,
        marginLeft: width / 100 * 2,
    },

});

const mapStateToProps = (state) => {
    return {
        CommonReducer: state.CommonReducer
    };
}

const mapDispatchToProps = (dispatch) => {
    return {
        // DashboardAction : () => { dispatch(DashboardAction()) },

    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Jobs_List);
