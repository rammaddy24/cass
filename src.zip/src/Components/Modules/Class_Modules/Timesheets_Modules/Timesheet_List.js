import React, { Component, PureComponent } from 'react'
import {
    StyleSheet, Text, Keyboard, AsyncStorage, FlatList,
    View, TouchableOpacity, Image, SafeAreaView, ImageBackground, BackHandler, Alert, Platform, Modal, TextInput, ScrollView, TouchableWithoutFeedback
} from 'react-native'
import { color, width, fontSize, fontFamily, height, LG_BG_THEME, Notify_THEME } from '../../../Constants/fontsAndColors'
import { Container, Content, connect, Picker, Header, LinearGradient, Snackbar, Splash_screen, Moment } from '../../../../Asset/Libraries/NpmList';
import { Mystatusbar } from '../../../../Asset/Libraries/index'

import Sample_json from '../Extra_Modules/Screenlist.json'

import { AS_HeaderDesign } from '../../CommonView_Modules/AS_HeaderDesign'
import { Card_Timesheets } from '../../CommonView_Modules/Card_Timesheets'

import Timelist_Response from '../Extra_Modules/Timelist.json'
import { Modal_Text } from '../../CommonView_Modules/Modal_Text'

import { Basic_Auth, Cass_APIKEY, List_Timesheet } from '././../../../Config/Server'
import { Spinner } from '../../../Config/Spinner';

class Timesheet_List extends Component {

    constructor(props) {
        super(props);
        this.state = {
            Timelist_ResponseArray: [],
            Info_Modal: false,
            StartDate: '',
            CassUserID: "",
            CassRoleID: '',
            Leave_SD: "",
            Dashboard_Fetching: false
        };

    }

    componentDidMount() {
        const { state } = this.props.navigation;
        let Calendar_Date = state.params.CalendarDate

        this.setState({
            StartDate: Calendar_Date == "" ? "" : Moment(Calendar_Date).format('DD-MMMM-YY'),
            Leave_SD: Calendar_Date == "" ? "" : Moment(Calendar_Date).format('YYYY-MM-DD'),

        })
        AsyncStorage.getItem("Cass_UserID", (error, Token_Result) => {
            if (Token_Result != "0" || Token_Result != null) {
                AsyncStorage.getItem("Cass_RoleID", (error, Token_RoleID) => {
                    if (Token_RoleID != "0" || Token_RoleID != null) {
                        this.setState({ CassUserID: Token_Result, CassRoleID: Token_RoleID, Dashboard_Fetching: true }, () => this._fetchdata(Token_Result, Token_RoleID));
                    }
                })
            }
        })
    }


    async _fetchdata(Token_Result, Token_RoleID) {
        const Timesheets_Response = await this._fetch_TSInfo(Token_Result, Token_RoleID);
        try {
            this.setState({
                Timelist_ResponseArray: Timesheets_Response.TS_Info,
                Dashboard_Fetching: false
            })
        } catch (err) {
            this.setState({ Dashboard_Fetching: false });
        }
    }

    _fetch_TSInfo(Token_Result, Token_RoleID) {
        return new Promise((resolve, reject) => {
            let TSInfo_URL = this.state.StartDate == "" ? List_Timesheet + Token_Result + "&user_role=" + Token_RoleID + Cass_APIKEY : List_Timesheet + Token_Result + "&user_role=" + Token_RoleID + "&date" + this.state.Leave_SD + Cass_APIKEY;

            fetch(TSInfo_URL, {
                method: 'GET',
                headers: Basic_Auth
            })
                .then((response) => response.json())
                .then((Jsonresponse) => {
                    let TS_Info = ""
                    if (Jsonresponse.status != false) {
                        TS_Info = Jsonresponse
                        resolve({ TS_Info });
                    } else {
                        reject(TS_Info)
                    }
                })
                .catch((error) => {
                    this.setState({ Dashboard_Fetching: false });
                    Snackbar.show({
                        title: "Internal Server Error..!",
                        duration: Snackbar.LENGTH_SHORT,
                    });
                });
        });
    }

    Container_Method(RouteName) {
        if (RouteName == "Goback") {
            this.props.navigation.goBack()
        } else if (RouteName == "Info") {
            this.setState({ Info_Modal: true })

        } else {
            Snackbar.show({
                title: 'Server Underconstruction..!',
                duration: Snackbar.LENGTH_SHORT,
            });
        }

    }

    Container_Model(RouteName) {
        this.setState({ Info_Modal: RouteName })
    }


    Render_Usercost(RouteName) {
        try {
            var mystring = []
            mystring = new String(RouteName);
            let Mystring_1 = (mystring.replace(/['"]+/g, '')).split("[")
            let Mystring_2 = (Mystring_1[1].replace(/['"]+/g, '')).split("]")
            let Mystring_Array = Mystring_2[0].split(",")
            let Results = 0
            for (let i = 0; i < Mystring_Array.length; i++) {
                Results += parseFloat(Mystring_Array[i])
            }
            return Results

        } catch (err) {

        }
    }

    Render_WorkQty(RouteName) {
        try {
            var mystring = []
            mystring = new String(RouteName);
            let Mystring_1 = (mystring.replace(/['"]+/g, '')).split("[")
            let Mystring_2 = Mystring_1[1].split(",")
            let Results = 0
            for (let i = 0; i < Mystring_2.length; i++) {
                Results = parseInt(Mystring_2[1].replace("qty:", ''))
            }
            return Results

        } catch (err) {

        }
    }

    render() {

        const { Dashboard_Fetching } = this.state;

        var spinner = false;
        if (Dashboard_Fetching == true) {
            spinner = <Spinner visibility={true} />
        } else {
            spinner = false
        }

        return (
            <LinearGradient key="background" start={{ x: 0, y: 0 }} end={{ x: 1, y: 0 }} colors={[LG_BG_THEME.APPTHEME_BG_2, LG_BG_THEME.APPTHEME_BG_2]} style={{ flex: 1, justifyContent: "center" }} >
                {spinner}

                <Mystatusbar />
                <View style={{ flex: 1 }}>
                    <AS_HeaderDesign
                        Onpress_LeftIcon={() => this.Container_Method("Goback")}
                        Onpress_RightIcon={() => this.Container_Method("Info")}
                        Header_Text={"TIMESHEETS"}
                        RightIcon_Status={"Info"}
                        LeftIcon_Status={true}
                    />

                    <View style={{ flex: 0.02 }} />
                    <View style={styles.Container_EP_2} />

                    <View style={{ flex: 0.08, justifyContent: 'center', flexDirection: "row" }}>

                        <View style={{ flexDirection: "row", flex: 0.395, justifyContent: 'center', alignItems: 'center' }}>

                            <View style={{ flex: 0.3, justifyContent: 'center', alignItems: "flex-end" }}>
                                <Image source={require('../../../../Asset/Icons/Calendar_Icon.png')} style={{ width: width / 100 * 3.5, height: width / 100 * 3.5, tintColor: LG_BG_THEME.APPTHEME_BLACK, }} />
                            </View>
                            <View style={{ flex: 0.7, justifyContent: 'center', alignItems: "flex-start" }}>
                                <Text style={styles.container_TabText}>{this.state.StartDate}</Text>
                            </View>
                        </View>


                        <View style={{ flex: 0.02, justifyContent: 'center' }} />

                        <View style={styles.Container_TimesheetHeader}>
                            <Text style={styles.container_TabText}>{"Total Timesheets - " + this.state.Timelist_ResponseArray.length}</Text>
                        </View>
                    </View>

                    <View style={{ flex: 0.9, marginTop: width / 100 * 2, marginLeft: width / 100 * 6, marginRight: width / 100 * 6 }}>
                        <TouchableWithoutFeedback onPress={Keyboard.dismiss}>

                            {this.state.Timelist_ResponseArray.length == 0 ?
                                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                    <Text style={styles.container_EmptyText}>{"No Timesheets Found..!"}</Text>
                                </View>
                                :
                                <FlatList style={{ flex: 1, }}
                                    data={this.state.Timelist_ResponseArray}
                                    showsVerticalScrollIndicator={false}
                                    keyExtractor={(item, index) => item.key}
                                    renderItem={({ item, index }) =>

                                        <Card_Timesheets
                                            CardList_AMORE={() => this.Container_Method()}
                                            Card_BG={item.dept_super_admin_status == "1" && item.dept_admin_status == "0" && item.finance_status == "0" && item.engineer_status == "0" ? Notify_THEME.AW_SUPERADMIN :
                                                item.dept_super_admin_status == "2" && item.dept_admin_status == "1" && item.finance_status == "0" && item.engineer_status == "0" ? Notify_THEME.AW_ADMIN :
                                                    item.dept_super_admin_status == "2" && item.dept_admin_status == "2" && item.finance_status == "2" && item.engineer_status == "0" ? Notify_THEME.AW_FINANCE :
                                                        item.dept_super_admin_status == "2" && item.dept_admin_status == "2" && item.finance_status == "2" && item.engineer_status == "0" ? Notify_THEME.AW_APPROVED : Notify_THEME.AW_REJECTED}
                                            CardText_Header1={"Job No : "}
                                            CardText_1={item.job_no}
                                            CardText_Header2={"Exchange : "}
                                            CardText_2={item.exchange}
                                            CardText_Header3={"Total :"}
                                            CardText_3={this.Render_Usercost(item.user_cost)}
                                            CardText_Header4={"Qty :"}
                                            CardText_4={this.Render_WorkQty(item.work_item_id_qty)}
                                            ActiveStatus={item.status == 2 ? true : false}
                                        />
                                    }
                                />
                            }
                        </TouchableWithoutFeedback>


                    </View>

                    <Modal
                        animationType='slide'
                        transparent={true}
                        visible={this.state.Info_Modal}
                        animationType="slide"
                        onRequestClose={() => { this.setState({ Info_Modal: false }) }}>

                        <View style={{ flex: 1, justifyContent: 'center', backgroundColor: 'rgba(0,0,0,0.5)' }}>
                            <View style={{ height: "100%", justifyContent: 'center', alignItems: 'center', backgroundColor: 'transparent' }}>
                                <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center', borderRadius: width / 100 * 2, flexDirection: "row" }}>

                                    <View style={{ flex: 0.1, }} />
                                    <View style={{ flex: 0.8, justifyContent: 'center' }}>

                                        <View style={{ height: width / 100 * 12, justifyContent: 'center', alignSelf: 'center', backgroundColor: LG_BG_THEME.APPTHEME_1, borderTopLeftRadius: width / 100 * 2, borderTopRightRadius: width / 100 * 2, flexDirection: 'row' }}>
                                            <View style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                                <Text numberOfLines={1} style={{ fontSize: fontSize.Medium, fontFamily: fontFamily.Poppins_Regular, letterSpacing: width / 100 * 0.1, color: color.Font_Whitecolor, textAlign: "center" }}>{"COLOUR INFO"}</Text>
                                            </View>
                                        </View>

                                        <View style={{ height: width / 100 * 70, justifyContent: 'center', backgroundColor: LG_BG_THEME.WHITE_THEME, }}>

                                            <View style={styles.Container_EP_2} />

                                            <Modal_Text
                                                Modal_Infotext={"Awaiting Dept Super Admin..!"}
                                                Modal_InfoBG={Notify_THEME.AW_SUPERADMIN}
                                            />

                                            <View style={styles.Container_EP_2} />

                                            <Modal_Text
                                                Modal_Infotext={"Awaiting Dept Admin..!"}
                                                Modal_InfoBG={Notify_THEME.AW_ADMIN}
                                            />

                                            <View style={styles.Container_EP_2} />

                                            <Modal_Text
                                                Modal_Infotext={"Awaiting Finance Dept..!"}
                                                Modal_InfoBG={Notify_THEME.AW_FINANCE}
                                            />

                                            <View style={styles.Container_EP_2} />

                                            <Modal_Text
                                                Modal_Infotext={"Timesheets Approved..!"}
                                                Modal_InfoBG={Notify_THEME.AW_APPROVED}
                                            />

                                            <View style={styles.Container_EP_2} />

                                            <Modal_Text
                                                Modal_Infotext={"Timesheets Rejected..!"}
                                                Modal_InfoBG={Notify_THEME.AW_REJECTED}
                                            />

                                            <View style={styles.Container_EP_2} />
                                        </View>

                                        <View style={{ height: width / 100 * 12, justifyContent: 'center', alignSelf: 'center', backgroundColor: LG_BG_THEME.APPTHEME_1, borderBottomLeftRadius: width / 100 * 2, borderBottomRightRadius: width / 100 * 2, flexDirection: 'row' }}>

                                            <TouchableOpacity onPress={() => this.Container_Model(false)} style={{ flex: 1, justifyContent: 'center', alignItems: 'center' }}>
                                                <Text numberOfLines={1} style={{ fontSize: fontSize.Medium, fontFamily: fontFamily.Poppins_Regular, letterSpacing: width / 100 * 0.1, color: color.Font_Whitecolor, textAlign: "center" }}>{"Cancel"}</Text>
                                            </TouchableOpacity>

                                        </View>
                                    </View>

                                    <View style={{ flex: 0.1, }} />

                                </View>

                            </View>
                        </View>
                    </Modal>

                </View>
            </LinearGradient>

        )
    }

}


const styles = StyleSheet.create({

    container_TabText: {
        fontSize: fontSize.lightMedium,
        fontFamily: fontFamily.Poppins_SemiBold,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.APPTHEME_BLACK,
        marginLeft: width / 100 * 2,
    },
    Container_EP_1: {
        height: height / 100 * 1
    },
    Container_EP_2: {
        height: height / 100 * 2
    },
    Container_EP_4: {
        height: height / 100 * 4
    },

    Container_TimesheetHeader: {
        flex: 0.59,
        justifyContent: 'center',
        alignItems: 'center',

    },
    Container_Infotext: {
        fontSize: fontSize.Medium,
        fontFamily: fontFamily.Poppins_Regular,
        letterSpacing: width / 100 * 0.1,
        color: color.Font_Black,
        textAlign: "center",
    },
    container_EmptyText: {
        fontSize: fontSize.Medium,
        fontFamily: fontFamily.Poppins_Bold,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.APPTHEME_BLACK,
        marginLeft: width / 100 * 2,
    },

});

const mapStateToProps = (state) => {
    return {
        // CommonReducer: state.CommonReducer
    };
}

const mapDispatchToProps = (dispatch) => {
    return {
        // DashboardAction : () => { dispatch(DashboardAction()) },

    }
}
export default connect(mapStateToProps, mapDispatchToProps)(Timesheet_List);
