import React, { Component } from 'react';
import {
    Text,
    View,
    TouchableOpacity,
    Image, StyleSheet
} from 'react-native'
import { color, BG_THEMECOLOUR, width, fontSize, fontFamily, height, LG_BG_THEME } from '../../Constants/fontsAndColors';
import { Container, Content, connect, Picker, Header, Toast, DeviceInfo, Snackbar, LinearGradient, Col, Row, Grid } from '../../../Asset/Libraries/NpmList';

export class Home_Timesheetscard extends Component {

    constructor(props) {
        super(props);

    }
    render() {

        return (

            <View
                style={{
                    height: height / 100 * 14, justifyContent: "center", flexDirection: 'row', borderRadius: width / 100 * 2, backgroundColor: this.props.Card_BG, elevation: Platform.OS == "android" ? width / 100 * 1 : width / 100 * 0.1,
                    shadowOffset: { width: 2, height: 2 }, shadowOpacity: 0.2, shadowColor: this.props.Card_BG, flexDirection: "row"
                }}>

                <View style={{ flex: 0.05 }} />

                <View style={{ flex: 0.3, justifyContent: 'center' }}>
                    <View style={{ flex: 0.2, justifyContent: "center", borderBottomColor: "#F34100", borderBottomWidth: width / 100 * 0.5, marginRight: width / 100 * 8, marginLeft: width / 100 * 3 }} />

                    <View style={{ flex: 0.3, justifyContent: 'center', alignItems: 'center' }}>
                        <Text numberOfLines={2} style={styles.container_HeaderText}>{this.props.CardHeader_1}</Text>
                    </View>

                    <View style={{ flex: 0.3, justifyContent: 'center', alignItems: 'center' }}>
                        <Text numberOfLines={2} style={styles.container_HeaderText}>{this.props.CardText_1}</Text>
                    </View>
                    <View style={{ flex: 0.2 }} />

                </View>

                <View style={{ flex: 0.3, justifyContent: 'center' }}>
                    <View style={{ flex: 0.2, justifyContent: "center", borderBottomColor: "#5757F2", borderBottomWidth: width / 100 * 0.5, marginRight: width / 100 * 8, marginLeft: width / 100 * 3 }} />

                    <View style={{ flex: 0.3, justifyContent: 'center', alignItems: 'center' }}>
                        <Text numberOfLines={2} style={styles.container_HeaderText}>{this.props.CardHeader_2}</Text>

                    </View>

                    <View style={{ flex: 0.3, justifyContent: 'center', alignItems: 'center' }}>
                        <Text numberOfLines={2} style={styles.container_HeaderText}>{this.props.CardText_2}</Text>

                    </View>
                    <View style={{ flex: 0.2 }} />

                </View>

                <View style={{ flex: 0.3, justifyContent: 'center' }}>
                    <View style={{ flex: 0.2, justifyContent: "center", borderBottomColor: "#F2E757", borderBottomWidth: width / 100 * 0.5, marginRight: width / 100 * 8, marginLeft: width / 100 * 3 }} />

                    <View style={{ flex: 0.3, justifyContent: 'center', alignItems: 'center' }}>
                        <Text numberOfLines={2} style={styles.container_HeaderText}>{this.props.CardHeader_3}</Text>

                    </View>

                    <View style={{ flex: 0.3, justifyContent: 'center', alignItems: 'center' }}>
                        <Text numberOfLines={2} style={styles.container_HeaderText}>{this.props.CardText_3}</Text>

                    </View>
                    <View style={{ flex: 0.2 }} />

                </View>
                <View style={{ flex: 0.05 }} />



            </View>
        )
    }
};

const styles = StyleSheet.create({
    container_Text: {
        fontSize: fontSize.lightMedium_50,
        fontFamily: fontFamily.Poppins_Regular,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.WHITE_THEME,
        textAlign: "auto",
        marginRight: width / 100 * 5
    },
    container_HeaderText: {
        fontSize: fontSize.lightMedium_50,
        fontFamily: fontFamily.Poppins_Regular,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.WHITE_THEME,
        textAlign: "auto",
        marginRight: width / 100 * 5,
    },
    container_ByText: {
        fontSize: fontSize.Medium,
        fontFamily: fontFamily.Poppins_Regular,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.WHITE_THEME,
        textAlign: "auto",
        //marginLeft: width / 100 * 8
    },



});

