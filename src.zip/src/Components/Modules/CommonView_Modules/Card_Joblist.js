import React, { Component } from 'react';
import {
    Text,
    View,
    TouchableOpacity,
    Image, StyleSheet
} from 'react-native'
import { color, BG_THEMECOLOUR, width, fontSize, fontFamily, height, LG_BG_THEME } from '../../Constants/fontsAndColors';
import { Container, Content, connect, Picker, Header, Toast, DeviceInfo, Snackbar, LinearGradient, Col, Row, Grid } from '../../../Asset/Libraries/NpmList';

export class Card_Joblist extends Component {

    constructor(props) {
        super(props);

    }
    render() {

        return (

            <View 
                style={{
                    height: height / 100 * 26, justifyContent: "center", borderRadius: width / 100 * 2, backgroundColor: this.props.Card_BG, marginBottom: width / 100 * 4, elevation: Platform.OS == "android" ? width / 100 * 1 : width / 100 * 0.1,
                    shadowOffset: { width: 2, height: 2 }, shadowOpacity: 0.2, shadowColor: LG_BG_THEME.APPTHEME_GREY_2,
                }}>

                <View style={{ flex: 0.65, justifyContent: "center", borderBottomWidth: width / 100 * 0.4, borderBottomColor: LG_BG_THEME.APPTHEME_GREY_2 }}>

                    <View style={{ flex: 0.05 }} />

                    <View style={{ flex: 0.25, justifyContent: 'center' }}>
                        <Text numberOfLines={1} style={styles.container_HeaderText}>{this.props.CardText_Header1} <Text style={styles.container_Text}>{this.props.CardText_1}</Text></Text>
                    </View>

                    <View style={{ flex: 0.25, justifyContent: 'center' }}>
                        <Text numberOfLines={1} style={styles.container_HeaderText}>{this.props.CardText_Header2} <Text style={styles.container_Text}>{this.props.CardText_2}</Text></Text>
                    </View>

                    <View style={{ flex: 0.25, justifyContent: 'center' }}>
                        <Text numberOfLines={1} style={styles.container_HeaderText}>{this.props.CardText_Header3} <Text style={styles.container_Text}>{this.props.CardText_3}</Text></Text>
                    </View>

                    <View style={{ flex: 0.2, justifyContent: 'center', flexDirection: 'row' }}>
                        <View style={{ flex: 0.6, justifyContent: 'center' }} />

                        <TouchableOpacity onPress={() => this.props.CardList_AMORE()} style={{ flex: 0.4, justifyContent: 'center', alignItems: 'center' }}>
                            <Text numberOfLines={1} style={styles.container_ThemeText}>{"Add More"}</Text>
                        </TouchableOpacity>

                    </View>
                </View>

                <View style={{ flex: 0.35, justifyContent: "center", }}>

                    <View style={{ flex: 0.6, justifyContent: 'center', alignItems: 'center' }}>
                        <Text numberOfLines={1} style={styles.container_HeaderText}>{this.props.CardTimesheet_Count}</Text>
                    </View>

                    <View style={{ flex: 0.3, justifyContent: 'center', alignItems: 'center', flexDirection: 'row' }}>
                        <View style={{ flex: 0.6, justifyContent: 'center', }} />

                        <TouchableOpacity onPress={() => this.props.CardList_VAll()} style={{ flex: 0.4, justifyContent: 'center', alignItems: 'center' }}>
                            <Text numberOfLines={1} style={styles.container_ThemeText}>{"View All"}</Text>
                        </TouchableOpacity>

                    </View>

                    <View style={{ flex: 0.1, justifyContent: 'center', }} />

                </View>

            </View>
        )
    }
};

const styles = StyleSheet.create({
    container_Text: {
        fontSize: fontSize.Medium,
        fontFamily: fontFamily.Poppins_Regular,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.APPTHEME_BLACK,
        textAlign: "auto",
        marginRight: width / 100 * 5,
        marginLeft: width / 100 * 5,
        opacity: 0.6
    },
    container_HeaderText: {
        fontSize: fontSize.Medium,
        fontFamily: fontFamily.Poppins_SemiBold,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.APPTHEME_BLACK,
        textAlign: "auto",
        marginRight: width / 100 * 5,
        marginLeft: width / 100 * 5,

    },
    container_ThemeText: {
        fontSize: fontSize.Medium,
        fontFamily: fontFamily.Poppins_SemiBold,
        letterSpacing: width / 100 * 0.1,
        color: LG_BG_THEME.APPTHEME_1,
        textAlign: "auto",
        marginRight: width / 100 * 5,
        marginLeft: width / 100 * 5,
    }



});

