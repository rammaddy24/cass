import { StyleSheet, Platform } from 'react-native';
export const Platform_isIOS = (Platform.OS == 'ios') ? true : false
export * from './axios';