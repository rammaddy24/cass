export const YOUTUBE_API_KEY = 'AIzaSyBUfAP3oMDGe4ydQws4DQttBr8uY5LozSA';
