import { NavigationActions } from 'react-navigation';

import { Stack } from '../../Router/Stack/navigationConfiguration';

export function stack(state, action) {
  switch (action.type) {
   
      case 'Cuddlers_MapOK': {
        const navigationAction = NavigationActions.navigate({
          routeName: 'Settings',
        });
        return Stack.router.getStateForAction(navigationAction, state);
      }
    default: return Stack.router.getStateForAction(action, state);
  }
}




