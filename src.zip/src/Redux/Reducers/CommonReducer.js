const initialState = {
  NotifyInfo_Response: [],
  UserInfo_Response: []
};

export default function CommonReducer(state = initialState, action) {
  switch (action.type) {

    // ----------------------------------- Registration_Modules ----------------------------------------//

    // --------------------onLoginAction--------------------

    case "NotifyInfo_Action":
      return {
        ...state,
        NotifyInfo_Response: action.NotifyInfo_Response,
      };

    case "UserInfo_Action":
      return {
        ...state,
        UserInfo_Response: action.UserInfo_Response,
      };

    default:
      return state;
  }
}





